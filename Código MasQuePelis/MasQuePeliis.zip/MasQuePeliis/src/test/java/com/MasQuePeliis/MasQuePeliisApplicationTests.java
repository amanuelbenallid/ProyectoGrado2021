package com.MasQuePeliis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MasQuePeliisApplicationTests {

	@Test
	void contextLoads() {
	}

}
