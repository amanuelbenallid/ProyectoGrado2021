package com.MasQuePeliis.models.entity;

//Importamos las clases Java necesarias para una entidad
import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

//Usamos las definiciones SpringBoot necesarias para definir que es una entidad y el nombre que tendra la tabla en la Base de datos
@Entity
@Table(name = "estrenos")
public class Estreno implements Serializable {
	// Establecemos que idestrenos sera la ID y primary key de la tabla
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idestrenos;
	// Declaramos las variables
	private String titulo, sinopsis, director, protagonista, ilustracion;
	private Integer anyo, duracion, generoid;

	// Generamos los Constructores , Getters and Setters
	public Integer getIdestrenos() {
		return idestrenos;
	}

	public void setIdestrenos(Integer idestrenos) {
		this.idestrenos = idestrenos;
	}

	public String getIlustracion() {
		return ilustracion;
	}

	public void setIlustracion(String ilustracion) {
		this.ilustracion = ilustracion;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getSinopsis() {
		return sinopsis;
	}

	public void setSinopsis(String sinopsis) {
		this.sinopsis = sinopsis;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getProtagonista() {
		return protagonista;
	}

	public void setProtagonista(String protagonista) {
		this.protagonista = protagonista;
	}

	public Integer getAnyo() {
		return anyo;
	}

	public void setAnyo(Integer anyo) {
		this.anyo = anyo;
	}

	public Integer getDuracion() {
		return duracion;
	}

	public void setDuracion(Integer duracion) {
		this.duracion = duracion;
	}

	public Integer getGeneroid() {
		return generoid;
	}

	public void setGeneroid(Integer generoid) {
		this.generoid = generoid;
	}

	public Estreno(Integer idestrenos, String titulo, String sinopsis, String director, String protagonista,
			Integer anyo, Integer duracion, Integer generoid) {
		super();
		this.idestrenos = idestrenos;
		this.titulo = titulo;
		this.sinopsis = sinopsis;
		this.director = director;
		this.protagonista = protagonista;
		this.anyo = anyo;
		this.duracion = duracion;
		this.generoid = generoid;
	}

	public Estreno() {

	}

	// Creamos un parseador de genero al cual se le pasa el id del genero y este lo
	// convierte en un String para un mejor tratamiento de los datos
	public static String parseIdGenero(Integer idgenero) {
		String genero = null;

		if (idgenero == 1) {
			genero = "Acción";
		} else {
			if (idgenero == 2) {
				genero = "Aventuras";
			} else {
				if (idgenero == 3) {
					genero = "Romántica";
				} else {
					if (idgenero == 4) {
						genero = "Comedia";
					} else {
						if (idgenero == 5) {
							genero = "Drama";
						} else {
							if (idgenero == 6) {
								genero = "Terror";
							} else {
								if (idgenero == 7) {
									genero = "Ciencia Ficción";
								} else {
									if (idgenero == 8) {
										genero = "Musical";
									} else {
										if (idgenero == 9) {
											genero = "Suspense";
										}
									}
								}
							}
						}
					}
				}
			}
		}

		return genero;
	}
}
