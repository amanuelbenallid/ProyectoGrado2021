package com.MasQuePeliis.models.entity;

//Importamos las clases Java necesarias para una entidad
import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.ManyToOne;

import javax.persistence.Table;

//Usamos las definiciones SpringBoot necesarias para definir que es una entidad y el nombre que tendra la tabla en la Base de datos
@Entity
@Table(name = "tops")
public class Top implements Serializable {

	// Establecemos que idtops sera la ID y primary key de la tabla
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	// Declaramos las variables
	private Integer idtops;
	private String nombre;
	private Integer generoid;
	// Establecemos que Top tendra una variable de tipo Usuario la
	// cual estará relacionada a su correpondiente tabla
	@ManyToOne
	private Usuario usuario;

	// Generamos los Constructores , Getters and Setters
	public Integer getIdtops() {
		return idtops;
	}

	public void setIdtops(Integer idtops) {
		this.idtops = idtops;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Integer getGeneroid() {
		return generoid;
	}

	public void setGeneroid(Integer generoid) {
		this.generoid = generoid;
	}

	public Top(Integer idtops, String nombre, Integer userid, Integer generoid, Usuario usuario) {
		super();
		this.idtops = idtops;
		this.nombre = nombre;
		this.generoid = generoid;
		this.usuario = usuario;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public void setIdUsuario(Integer idusuario) {
		this.usuario.setIduser(idusuario);
	}

	public Top() {
		super();
	}

	// Creamos un parseador de Género para un mejor tratamiento de los datos en la
	// vista
	public static String parseIdGenero(Integer idgenero) {
		String genero = null;

		if (idgenero == 1) {
			genero = "Acción";
		} else {
			if (idgenero == 2) {
				genero = "Aventuras";
			} else {
				if (idgenero == 3) {
					genero = "Romántica";
				} else {
					if (idgenero == 4) {
						genero = "Comedia";
					} else {
						if (idgenero == 5) {
							genero = "Drama";
						} else {
							if (idgenero == 6) {
								genero = "Terror";
							} else {
								if (idgenero == 7) {
									genero = "Ciencia Ficción";
								} else {
									if (idgenero == 8) {
										genero = "Musical";
									} else {
										if (idgenero == 9) {
											genero = "Suspense";
										}
									}
								}
							}
						}
					}
				}
			}
		}

		return genero;
	}

}
