package com.MasQuePeliis.models.service;

import java.util.List;

import com.MasQuePeliis.models.entity.Usuario;

//Definimos los métodos necesarios que usaremos en la aplicación
public interface IUsuarioService {
	public Usuario findbyUsername(String username);

	public Usuario registrar(Usuario u);

	public Usuario findbyIdUser(Integer iduser);

	int save(Usuario u);

	List<Usuario> leerUsuariosActivos();

	List<Usuario> leerUsuariosInactivos();

	void deleteUser(Integer id);

}
