package com.MasQuePeliis.models.service;

import java.util.List;

import com.MasQuePeliis.models.entity.Estreno;

//Definimos los métodos necesarios que usaremos en la aplicación
public interface IEstrenoService {
	List<Estreno> leerEstrenos();

	void deleteEstreno(Integer estrenoid);

	Estreno registrarEstrenos(Estreno e);

}
