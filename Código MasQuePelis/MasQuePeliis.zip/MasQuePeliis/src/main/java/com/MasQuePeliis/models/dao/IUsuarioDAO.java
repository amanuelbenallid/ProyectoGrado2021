package com.MasQuePeliis.models.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.MasQuePeliis.models.entity.Usuario;

//Creamos la conexion con el repositorio de Usuarios usando JPARepository y además indicamos que la primary key de Usuario
//es de tipo Integer
@Repository
public interface IUsuarioDAO extends JpaRepository<Usuario, Integer> {
	public Usuario findByUsername(String username);

	public Usuario findByIduser(Integer iduser);

}
