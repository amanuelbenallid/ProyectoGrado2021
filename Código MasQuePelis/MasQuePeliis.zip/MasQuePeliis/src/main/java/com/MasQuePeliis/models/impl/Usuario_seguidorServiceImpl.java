package com.MasQuePeliis.models.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MasQuePeliis.models.dao.IUsuarioDAO;
import com.MasQuePeliis.models.dao.IUsuario_seguidorDAO;

import com.MasQuePeliis.models.entity.Usuario;
import com.MasQuePeliis.models.entity.Usuario_seguidor;
import com.MasQuePeliis.models.service.IUsuario_seguidorService;

@Service
public class Usuario_seguidorServiceImpl implements IUsuario_seguidorService {
	// Declaramos las variables usando Autowired para inyectar las dependencias de
	// las clases correspondientes
	@Autowired
	private IUsuario_seguidorDAO data;

	@Autowired
	private IUsuarioDAO datados;

	// Usamos Override para hacer referencia a otro metodo e implementarlo
	@Override
	// Creamos un método que nos devuelve una lista con los usuarios seguidores de
	// la plataforma, es decir que siguen a otro usuario(el que proporciona el id)
	public List<Usuario> leerUsuariosSeguidores(Integer id) {
		List<Usuario> listausuarios = new ArrayList<Usuario>();
		// Creamos un bucle que recorra todos los seguimientos de la plataforma
		for (int i = 0; i <= data.findAll().size() - 1; i++) {
			// creamos la condicion que si el usuario que sigue del seguimiento es igual al
			// ID y no esta ya incluido en la lista de usuarios entonces se incluya en la
			// lista
			if (data.findAll().get(i).getUser_idfollower() == id
					&& !listausuarios.contains(datados.findByIduser(data.findAll().get(i).getUsuario().getIduser()))) {
				listausuarios.add(datados.findByIduser(data.findAll().get(i).getUsuario().getIduser()));

			}

		}
		// Creamos la condicion que si se incluye el usuario a si mismo en la lista ,
		// este sea eliminado de ella y no se muestre
		if (listausuarios.contains(datados.getById(id))) {
			listausuarios.remove(datados.getById(id));
		}
		return (List<Usuario>) listausuarios;
	}

	@Override
	// Creamos el método inverso del anterior , es decir los usuarios que no siguen
	// , este recibe un ID del usuario y devuelve una lista con los usuarios que no
	// conoce
	public List<Usuario> leerUsuariosNoSeguidores(Integer id) {

		List<Usuario> listaUsuariosSeguidores = leerUsuariosSeguidores(id);
		List<Usuario> listausuarios = new ArrayList<Usuario>();

		for (int i = 0; i <= datados.findAll().size() - 1; i++) {
			if (!listaUsuariosSeguidores.contains(datados.findAll().get(i))) {
				listausuarios.add(datados.findAll().get(i));
			}

		}

		if (listausuarios.contains(datados.getById(id))) {
			listausuarios.remove(datados.getById(id));
		}
		return (List<Usuario>) listausuarios;
	}

	@Override
	// Con este método registramos un nuevo seguimiento en la plataforma y lo
	// guardamos en la Base de datos
	public Usuario_seguidor registrarSeguimiento(Integer idseguidor, Integer idseguido) {

		Usuario_seguidor u = new Usuario_seguidor();
		u.setUser_idfollower(idseguidor);
		u.setUsuario(datados.findByIduser(idseguido));

		return data.save(u);
	}

	@Override
	// Con este método eliminamos un seguimiento , le pasamos el id del usuario que
	// maneja el sistema en ese momento y el usuario que desea dejar de seguir y
	// busca en la lista de todos los seguimientos hasta que encuentre la condicion
	// que se cumpla y lo borre
	public void dejarDeSeguir(Integer idusuario, Integer idusuarioseguidor) {

		for (int i = 0; i <= data.findAll().size() - 1; i++) {
			if (data.findAll().get(i).getUser_idfollower() == idusuario
					&& data.findAll().get(i).getUsuario().getIduser() == idusuarioseguidor) {

				data.deleteById(data.findAll().get(i).getIdseguimiento());
			}

		}

	}

}
