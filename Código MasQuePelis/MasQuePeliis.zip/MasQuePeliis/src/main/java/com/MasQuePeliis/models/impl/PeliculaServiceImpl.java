package com.MasQuePeliis.models.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MasQuePeliis.models.dao.IPeliculaDAO;

import com.MasQuePeliis.models.entity.Pelicula;
import com.MasQuePeliis.models.entity.Top;
import com.MasQuePeliis.models.service.IPeliculaService;

@Service
public class PeliculaServiceImpl implements IPeliculaService {

	// Declaramos las variables usando Autowired para inyectar las dependencias de
	// las clases correspondientes
	@Autowired
	private IPeliculaDAO data;

	// Usamos Override para hacer referencia a otro metodo e implementarlo
	@Override
	// En este método le pasamos el ID del top que deseamos obtener las peliculas y
	// nos devuelve una lista con todas las peliculas que pertenecen a ese Top
	public List<Pelicula> leerPeliculas(Integer idtop) {

		List<Pelicula> listapeliculas = new ArrayList<Pelicula>();
		;

		for (int i = 0; i <= data.findAll().size() - 1; i++) {
			if (data.findAll().get(i).getTop().getIdtops() == idtop) {
				listapeliculas.add(data.findAll().get(i));
			}

		}

		return (List<Pelicula>) listapeliculas;
	}

	// Este método recibe por parámetro un ID de un Top y devuelve un valor booleano
	// en el que se le dice que busque todas las peliculas de cierto Top y las
	// elimine todas de la Base de datos
	@Override
	public Boolean eliminaPelicula(Integer idtop) {

		Boolean eliminado = false;
		for (int i = 0; i <= data.findAll().size() - 1; i++) {
			if (data.findAll().get(i).getTop().getIdtops() == idtop) {
				data.deleteById(data.findAll().get(i).getIdpeliculas());
				eliminado = true;
			}

		}
		return eliminado;

	}

	// Este método lo usamos para registrar una pelicula creada por el usuario en la
	// Base de datos de la plataforma
	@Override
	public Pelicula registrarPelicula(Pelicula p) {

		return data.save(p);
	}

	// Creamos un método con el cual le pasamos el ID de la pelicula que deseamos
	// borrar
	@Override
	public void deletePelicula(int idpelicula) {
		data.deleteById(idpelicula);

	}

	@Override
	// Creamos un método para que a traves del ID de la pelicula se encuentre el Top
	// al que pertenece
	public Top encuentraTop(int idpelicula) {

		return data.getById(idpelicula).getTop();
	}
}
