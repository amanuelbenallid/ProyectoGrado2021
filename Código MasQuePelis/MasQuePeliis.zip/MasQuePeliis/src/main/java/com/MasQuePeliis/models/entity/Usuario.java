package com.MasQuePeliis.models.entity;

//Importamos las clases Java necesarias para una entidad
import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

//Usamos las definiciones SpringBoot necesarias para definir que es una entidad y el nombre que tendrá la tabla en la Base de datos
@Entity
@Table(name = "user")
public class Usuario implements Serializable {

	// Declaramos las variables
	private String username, password, nombre, apellido, email, role, state;
	// Establecemos que iduser será la ID y primary key de la tabla
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer iduser;

	// Generamos los Constructores , Getters and Setters

	public Usuario(String username, String password, String nombre, String apellido, String email, String role,
			String state, Integer iduser) {
		super();
		this.username = username;
		this.password = password;
		this.nombre = nombre;
		this.apellido = apellido;
		this.email = email;
		this.role = "user";
		this.state = "activo";
		this.iduser = iduser;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Integer getIduser() {
		return iduser;
	}

	public void setIduser(Integer iduser) {
		this.iduser = iduser;
	}

	public Usuario() {
		super();
	}

	private static final long serialVersionUID = 1L;

}
