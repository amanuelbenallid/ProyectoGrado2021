package com.MasQuePeliis.models.service;

import java.util.List;

import com.MasQuePeliis.models.entity.Pelicula;
import com.MasQuePeliis.models.entity.Top;

//Definimos los métodos necesarios que usaremos en la aplicación
public interface IPeliculaService {
	List<Pelicula> leerPeliculas(Integer idtop);

	public Boolean eliminaPelicula(Integer idtop);

	Pelicula registrarPelicula(Pelicula p);

	void deletePelicula(int idpelicula);

	Top encuentraTop(int idpelicula);

}
