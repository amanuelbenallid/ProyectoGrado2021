package com.MasQuePeliis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

//Clase principal de la aplicación
@SpringBootApplication
public class MasQuePeliisApplication extends SpringBootServletInitializer{
	
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		return builder.sources(MasQuePeliisApplication.class);
	}

	public static void main(String[] args) {
		SpringApplication.run(MasQuePeliisApplication.class, args);
	}

}
