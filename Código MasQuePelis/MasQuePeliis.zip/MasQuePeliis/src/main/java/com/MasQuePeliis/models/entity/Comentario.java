package com.MasQuePeliis.models.entity;

//Importamos las clases Java necesarias para una entidad
import java.io.Serializable;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

//Usamos las definiciones SpringBoot necesarias para definir que es una entidad y el nombre que tendra la tabla en la Base de datos
@Entity
@Table(name = "comentarios")
public class Comentario implements Serializable {
	private static final long serialVersionUID = 1L;
	// Establecemos que idcomentarios sera la ID y primary key de la tabla
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idcomentarios;
	// Declaramos las variables
	private String contenidocomentario;
	private Date fecha;

	// Establecemos que Comentario tendra dos variables de tipo Top y Usuario las
	// cuales estaran relacionadas a sus correpondientes tablas
	@ManyToOne
	private Top top;

	@ManyToOne
	private Usuario usuario;

	// Generamos los Constructores , Getters and Setters
	public Integer getIdcomentarios() {
		return idcomentarios;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public void setIdcomentarios(Integer idcomentarios) {
		this.idcomentarios = idcomentarios;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Top getTop() {
		return top;
	}

	public void setTop(Top top) {
		this.top = top;
	}

	public Comentario(Integer idcomentarios, String contenidocomentario, Date fecha, Top top, Usuario usuario) {
		super();
		this.idcomentarios = idcomentarios;
		this.contenidocomentario = contenidocomentario;
		this.fecha = fecha;
		this.top = top;
		this.usuario = usuario;
	}

	public String getContenidocomentario() {
		return contenidocomentario;
	}

	public void setContenidocomentario(String contenidocomentario) {
		this.contenidocomentario = contenidocomentario;
	}

	public Comentario() {

	}

}
