package com.MasQuePeliis.models.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.MasQuePeliis.models.entity.Comentario;

//Creamos la conexion con el repositorio de Comentarios usando JPARepository y además indicamos que la primary key de Comentario
//es de tipo Integer
@Repository
public interface IComentarioDAO extends JpaRepository<Comentario, Integer> {

}
