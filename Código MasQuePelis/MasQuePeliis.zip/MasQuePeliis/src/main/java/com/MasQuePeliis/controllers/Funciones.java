package com.MasQuePeliis.controllers;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.MasQuePeliis.models.entity.Comentario;
import com.MasQuePeliis.models.entity.Estreno;
import com.MasQuePeliis.models.entity.Pelicula;
import com.MasQuePeliis.models.entity.Top;
import com.MasQuePeliis.models.entity.Usuario;
import com.MasQuePeliis.models.entity.Usuario_seguidor;
import com.MasQuePeliis.models.service.IComentarioService;
import com.MasQuePeliis.models.service.IEstrenoService;
import com.MasQuePeliis.models.service.IPeliculaService;
import com.MasQuePeliis.models.service.ITopService;
import com.MasQuePeliis.models.service.IUsuarioService;
import com.MasQuePeliis.models.service.IUsuario_seguidorService;
//Controlador de la aplicacion donde se mapean las rutas de la aplicación 

//Declaramos las anotaciones SpringBoot correspondiente a un controlador
@Controller
@RequestMapping("/base") // establecemos que todo el mapeo de esta clase deba empezar por /base
public class Funciones {

	// Declaramos las variables usando Autowired para inyectar las dependencias de
	// las clases correspondientes
	@Autowired
	private ITopService service;

	@Autowired
	private IPeliculaService servicedos;

	@Autowired
	private IUsuarioService servicetres;

	@Autowired
	private IEstrenoService servicecuatro;

	@Autowired
	private IUsuario_seguidorService servicecinco;

	@Autowired
	private IComentarioService serviceseis;

	// Se declara el mapeo para dirigirnos a la página principal, en la cual
	// obtenemos los valores de la sesión correspondientes al nombre
	// Le damos valor a la lista de tops usando model y llamando al método que
	// obtiene todos los tops de la aplicacion.
	@GetMapping("/TopsInicio")
	public String leerTops(Model model, Authentication auth, HttpSession session) {
		List<Top> tops = service.leerTops();
		model.addAttribute("tops", tops);

		String username = auth.getName();
		if (session.getAttribute("usuario") == null) {

			Usuario usuario = servicetres.findbyUsername(username);
			usuario.setPassword(null);
			session.setAttribute("usuario", usuario);

		}
		return "topsinicio";
	}

	// Creamos el mapeo para dirigirnos hacia el perfil del usuario activo en el
	// cual obtenemos desde html el valor de la ID del usuario
	// Usando model le damos valor al usuario rellenándolo con los datos obtenidos
	// del método al cual le pasamos la ID , ademas también,
	// le damos valor a tops , rellenandolo con los datos de los tops creados por el
	// usuario.
	@GetMapping("/miperfil/{iduser}")
	public String miperfil(@PathVariable Integer iduser, Model model) {

		Usuario usuario = servicetres.findbyIdUser(iduser);
		model.addAttribute("usuario", usuario);
		List<Top> tops = service.leerTopsMiperfil(iduser);
		model.addAttribute("tops", tops);

		if (usuario.getRole().equals("user")) {
			return "miperfil";
		} else {
			return "miperfiladmin";
		}

	}

	// Desde este mapeo hacemos una redireccion a la pagina html desde la cual
	// rellenamos el formulario para editar los datos del usuario.
	// Para ello obtenemos la id del usuario activo y volcamos todos los datos sobre
	// la variable usuario.
	@GetMapping("/editaruser/{iduser}")
	public String editaruser(@PathVariable Integer iduser, Model model) {

		Usuario usuario = servicetres.findbyIdUser(iduser);
		model.addAttribute("usuario", usuario);

		return "editaruser";
	}

	// Una vez se hayan introducido los datos nuevos del usuario con este método
	// conseguimos que se guarden los datos y nos redirija
	// hacia el mapeo anterior visto donde se nos muestra el perfil del usuario.
	@PostMapping("/save")
	public String save(@Validated Usuario u, Model model) {
		servicetres.save(u);

		return "redirect:/base/miperfil/" + u.getIduser();
	}

	// Desde este mapeo nos redirigira hacia la pagina del panel de administracion
	// desde el cual nos mostrara un abanico de opciones
	@GetMapping("/administracion")
	public String administracion() {

		return "paneladministracion";
	}

	// En este metodo introducimos todos los estrenos de la plataforma en la
	// variable estrenos usando Model
	@GetMapping("/administracionestrenos")
	public String administracionestrenos(Model model) {

		List<Estreno> estrenos = servicecuatro.leerEstrenos();
		model.addAttribute("estrenos", estrenos);

		return "administracionestrenos";
	}

	// Desde este mapeo el usuario es capaz de pasarle la ID del estreno
	// seleccionado y eliminarlo llamando al metodo requerido para su eliminación
	@GetMapping("/eliminarEstreno/{id}")
	public String deleteestreno(Model model, @PathVariable int id) {

		servicecuatro.deleteEstreno(id);
		return "redirect:/base/administracionestrenos";
	}

	// Desde este método creamos un nuevo estreno y usando model lo llamamos
	// "estreno" en el que se recogeran los valores del nuevo estreno y
	// posteriormente se nos redirigira hacia la pagina en la que se ubica el
	// correspondiente formulario
	@GetMapping("/crearEstreno")
	public String creaestreno(Model model) {
		model.addAttribute("estreno", new Estreno());
		return "creaestreno";
	}

	// Desde este Post podremos guardar los datos introducidos en el formulario de
	// creacion de estrenos usando el metodo definido para su creación
	@PostMapping("/saveEstreno")
	public String saveEstreno(Estreno estreno, Model model) {

		model.addAttribute("estreno", servicecuatro.registrarEstrenos(estreno));

		return "redirect:/base/administracion";
	}

	// Desde este mapeo obtendremos una lista de todos los usuarios que se
	// encuentran actualmente activos en la aplicación y se nos redirigira hacia la
	// correspondiente pagina html
	@GetMapping("/usuariosActivos")
	public String leerUsuariosActivos(Model model) {
		List<Usuario> usuarios = servicetres.leerUsuariosActivos();
		model.addAttribute("usuarios", usuarios);

		return "administracionuseractivo";
	}

	// Desde este mapeo obtendremos una lista de todos los usuarios que se
	// encuentran actualmente suspendidos en la aplicación y se nos redirigira hacia
	// la
	// correspondiente pagina html
	@GetMapping("/usuariosInactivos")
	public String leerUsuariosInactivos(Model model) {
		List<Usuario> usuarios = servicetres.leerUsuariosInactivos();
		model.addAttribute("usuarios", usuarios);

		return "administracionuserinactivo";
	}

	// Usando este método al cual le pasaremos la ID del usuario conseguimos que se
	// elimine el usuario en cuestion de la Base de Datos y ademas se nos redirigira
	// al mapeo que nos muestra la lista de todos los usuarios activos en la
	// plataforma
	@GetMapping("/eliminarUserActivo/{id}")
	public String deleteUserActivo(Model model, @PathVariable int id) {
		Usuario u = servicetres.findbyIdUser(id);
		if (u.getRole().equals("user")) {
			servicetres.deleteUser(id);
		}

		return "redirect:/base/usuariosActivos";
	}

	// Usando este método al cual le pasaremos la ID del usuario conseguimos que se
	// elimine el usuario en cuestion de la Base de Datos y ademas se nos redirigira
	// al mapeo que nos muestra la lista de todos los usuarios suspendidos en la
	// plataforma
	@GetMapping("/eliminarUserInactivo/{id}")
	public String deleteUserInactivo(Model model, @PathVariable int id) {

		servicetres.deleteUser(id);
		return "redirect:/base/usuariosInactivos";
	}

	// Con este mapeo al cual le pasamos la ID del usuario seleccionado , haremos
	// que el estado del usuario pase a inactivo o suspendido y se nos redirija al
	// mapeo el cual nos muestra toda la lista de usuarios activos de la plataforma
	@GetMapping("/desactivarUsuario/{id}")
	public String desactivarusuario(Model model, @PathVariable int id) {

		Usuario u = servicetres.findbyIdUser(id);
		u.setState("inactivo");

		servicetres.save(u);
		return "redirect:/base/usuariosActivos";
	}

	// Con este mapeo al cual le pasamos la ID del usuario seleccionado , haremos
	// que el estado del usuario pase a activo y se nos redirija al
	// mapeo el cual nos muestra toda la lista de usuarios suspendidos de la
	// plataforma
	@GetMapping("/activarUsuario/{id}")
	public String activarusuario(Model model, @PathVariable int id) {

		Usuario u = servicetres.findbyIdUser(id);
		u.setState("activo");

		servicetres.save(u);
		return "redirect:/base/usuariosInactivos";
	}

	// Con este metodo haremos que se nos redirija hacia la pagina donde se nos
	// muestran todos los tops existentes en la plataforma , le damos
	// valor a la variable tops en la cual almacenamos la lista de los tops y con
	// Model le indicamos que se añadan al atributo "tops"
	@GetMapping("/topsAdmin")
	public String leerTopsAdmin(Model model) {
		List<Top> tops = service.leerTops();
		model.addAttribute("tops", tops);

		return "administraciontops";
	}

	// Desde este mapeo al cual le pasamos el ID del top seleccionado podemos
	// eliminar el top indicado y se nos redirigira hacia el mapeo que nos mandará a
	// la pantalla inicial de la aplicación
	@GetMapping("/eliminarTop/{id}")
	public String deleteTop(Model model, @PathVariable int id) {

		service.deleteTop(id);
		return "redirect:/base/topsAdmin";

	}

	// Este método se usa para que el usuario pueda eliminar el top seleccionado
	// desde su perfil , al método le pasamos el id del top y mediante auth
	// obtenemos la ID del usuario que lo posee y posteriormente nos dirige a la
	// pantalla de inicio de la plataforma
	@GetMapping("/eliminarTopMiPerfil/{id}")
	public String deleteTopmiPerfil(Model model, @PathVariable int id, Authentication auth, HttpSession session) {

		service.deleteTop(id);

		List<Top> tops = service.leerTops();
		model.addAttribute("tops", tops);

		String username = auth.getName();
		if (session.getAttribute("usuario") == null) {

			Usuario usuario = servicetres.findbyUsername(username);
			usuario.setPassword(null);
			session.setAttribute("usuario", usuario);

		}
		return "topsinicio";

	}

	// Este metodo se usa para que nos llene la variable "estrenos" con una lista de
	// todos los estrenos de la plataforma y nos dirija hacia la pantalla de
	// estrenos
	@GetMapping("/estrenos")
	public String leerestrenos(Model model) {

		List<Estreno> estrenos = servicecuatro.leerEstrenos();
		model.addAttribute("estrenos", estrenos);

		return "estrenos";
	}

	// En este mapeo el usuario pasara la ID del propio usuario y obtendremos una
	// lista con todos los usuarios a los que el usuario sigue y además una variable
	// donde se almacenarán el número de seguidos que tiene el usuario y luego se
	// nos mandará a la página donde se muestren los datos
	@GetMapping("/vertopseguidores/{id}")
	public String verseguidores(@PathVariable int id, Model model) {

		List<Usuario> usuariosseguidores = servicecinco.leerUsuariosSeguidores(id);
		model.addAttribute("usuariosseguidores", usuariosseguidores);

		model.addAttribute("contadorseguidores", usuariosseguidores.size());

		return "seguidores";
	}

	// En este método el usuario nos pasara una String donde se almacena el tipo de
	// categoria del cual se desea ver los tops , para ello guardamos en una
	// variable de tipo Lista todos los tops que pertenezcan a ese genero y luego se
	// nos mandara a la pagina donde se muestren los datos
	@GetMapping("/vertopcategoria/{categoria}")
	public String vercategoria(@PathVariable String categoria, Model model) {

		List<Top> topscategoria = service.leerTopsCategoria(categoria);
		model.addAttribute("tops", topscategoria);

		model.addAttribute("genero", categoria);

		return "categoria";

	}

	// Con este método al cual le pasa el ID del usuario nos dirige a la pantalla
	// donde se visualiza al usuario seleccionado, además se aportan todos los datos
	// y variable svacias necesarias para que el usuario pueda realizar todas las
	// funciones previstas para la aplicación
	@GetMapping("/verusuario/{id}")
	public String verusuario(@PathVariable int id, Authentication auth, Model model) {
		Usuario u = servicetres.findbyIdUser(id);
		model.addAttribute("usuario", u);

		List<Top> tops = service.leerTopsMiperfil(id);
		model.addAttribute("tops", tops);

		model.addAttribute("usuario_seguidor", new Usuario_seguidor());

		model.addAttribute("listausuariosquesigue",
				servicecinco.leerUsuariosSeguidores(servicetres.findbyUsername(auth.getName()).getIduser()));

		return "usuario";
	}

	// Desde este Post el usuario activo que ha iniciado sesión podra seguir al
	// usuario que esta visualizando y posteriormente se le redirigirá hacia el
	// mapeo de ver el usuario al que acaba de seguir
	@PostMapping("/saveSeguir/{id}")
	public String saveTop(@PathVariable int id, Authentication auth, Model model) {

		Integer idseguidor = servicetres.findbyUsername(auth.getName()).getIduser();
		servicecinco.registrarSeguimiento(idseguidor, id);

		Usuario u = servicetres.findbyIdUser(id);
		model.addAttribute("usuario", u);
		List<Top> tops = service.leerTopsMiperfil(id);
		model.addAttribute("tops", tops);

		return "redirect:/base/verusuario/{id}";
	}

	// Desde este Get el usuario activo que ha iniciado sesión podra dejar de seguir
	// al
	// usuario que esta visualizando y posteriormente se le redirigirá hacia el
	// mapeo de ver el usuario al que acaba de dejar de seguir
	@GetMapping("/DejarDeSeguir/{id}")
	public String dejarDeSeguir(Model model, @PathVariable int id, Authentication auth) {

		Integer idusuario = servicetres.findbyUsername(auth.getName()).getIduser();
		servicecinco.dejarDeSeguir(idusuario, id);

		return "redirect:/base/verusuario/{id}";

	}

	// En este mapeo el usuario sera redirigido al formulario desde el cual podra
	// crear su propio top y con Model creamos un top vacio listo para rellenarlo
	@GetMapping("/crearTop")
	public String creaTop(Model model) {
		model.addAttribute("top", new Top());
		return "creatop";
	}

	// Al llamar a este Post el usuario pasa su ID de usuario y se guarda el top que
	// acaba de crear y posteriormente se le dirige hacia la vista de ese nuevo top
	// que este listo para rellenar
	@PostMapping("/saveTop/{id}")
	public String saveTop(Top top, @PathVariable int id, Model model) {

		top.setUsuario(servicetres.findbyIdUser(id));

		model.addAttribute("top", service.registrarTop(top));

		return "redirect:/base/vertop/" + top.getIdtops();
	}

	// Desde este Get al cual el usuario pasara el ID del top que desea visualizar
	// se aportaran los datos del top en cuestion, las peliculas que lo forman y
	// todos los comentarios que posee
	@GetMapping("/vertop/{idtop}")
	public String vertop(@PathVariable int idtop, Model model) {

		Top top = service.findTopByid(idtop);
		model.addAttribute("top", top);

		List<Pelicula> peliculas = servicedos.leerPeliculas(idtop);
		model.addAttribute("peliculas", peliculas);

		List<Comentario> comentarios = serviceseis.leerComentariosbyId(idtop);
		model.addAttribute("comentarios", comentarios);
		model.addAttribute("comentario", new Comentario());

		return "top";
	}

	// Con este método al cual el usuario pasa el ID del top seleccionado ,el
	// usuario podra guardar el comentario que ha escrito en la Base de datos y
	// asociarla al top del que desea dar su opinion y finalmente le será redirigido
	// a otro mapeo el cual le mostrará el top
	@PostMapping("/saveComentario/{idtop}")
	public String saveComentario(Comentario comentario, @PathVariable int idtop, Authentication auth, Model model) {

		String username = auth.getName();
		Integer idusuario = servicetres.findbyUsername(username).getIduser();

		comentario.setTop(service.findTopByid(idtop));
		comentario.setUsuario(servicetres.findbyIdUser(idusuario));
		java.util.Date fecha = new Date();

		comentario.setFecha(fecha);

		model.addAttribute("comentario", serviceseis.registrarComentario(comentario));
		model.addAttribute("idtop", idtop);

		return "redirect:/base/vertop/{idtop}";
	}

	// Con este método el usuario aporta el ID del top y se le dirigirá a la
	// pantalla para poder agregar peliculas y relacionarlas con el top seleccionado
	@GetMapping("/agregaPeliculas/{idtop}")
	public String agregaPeliculas(@PathVariable int idtop, Model model) {
		model.addAttribute("pelicula", new Pelicula());
		model.addAttribute("idtop", idtop);
		return "creapelicula";
	}

	// Desde este método Post el usuario podrá guardar los cambios de la película
	// creada y asociada al top seleccionado , del cual pasa su ID y finalmente se
	// le dirigirá a otro mapeo que muestra todos los datos del Top
	@PostMapping("/savePelicula/{idtop}")
	public String savePelicula(Pelicula peli, @PathVariable int idtop, Model model) {

		peli.setTop(service.findTopByid(idtop));

		model.addAttribute("pelicula", servicedos.registrarPelicula(peli));
		model.addAttribute("idtop", idtop);

		return "redirect:/base/vertop/{idtop}";
	}

	// Desde este GET creamos un array de contadores donde se lleva la cuenta del
	// numero de Tops de cada categoría que existen en la plataforma y nos dirigirá
	// a la vista de estadísticas de la aplicación
	@GetMapping("/estadisticas")
	public String estadisticas(Model model) {
		Integer[] contadores = new Integer[10];
		contadores[0] = null;
		contadores[1] = service.contadorAccion();
		contadores[2] = service.contadorAventuras();
		contadores[3] = service.contadorRomanticas();
		contadores[4] = service.contadorComedia();
		contadores[5] = service.contadorDrama();
		contadores[6] = service.contadorTerror();
		contadores[7] = service.contadorCFiccion();
		contadores[8] = service.contadorMusical();
		contadores[9] = service.contadorSuspense();

		model.addAttribute("contadores", contadores);
		return "estadisticas";
	}

	// Desde este Mapeo se pasa el ID de usuario propio , se le da valor a una
	// variable de lista con los valores de los usuarios a los cuales el usuario no
	// sigue y se pasa a la pagina para que procese los datos y los muestre en la
	// pantalla de explorar
	@GetMapping("/explorar/{id}")
	public String verexplorar(@PathVariable int id, Model model) {

		List<Usuario> usuariosnoseguidores = servicecinco.leerUsuariosNoSeguidores(id);
		model.addAttribute("usuariosnoseguidores", usuariosnoseguidores);

		return "explorar";
	}

	// Desde este método al cual se le pasa el ID del comentario seleccionado se
	// borrara el comentario y luego redirigirá al usuario de vuelta al Top que
	// estaba viendo
	@GetMapping("/eliminarComentario/{idcomentario}")
	public String deleteComentario(Model model, @PathVariable int idcomentario) {

		Integer idtop = serviceseis.encuentraTop(idcomentario).getIdtops();
		serviceseis.deleteComentario(idcomentario);

		return "redirect:/base/vertop/" + idtop;
	}

	// Desde este método al cual se le pasa el ID de la película seleccionada se
	// borrara la pelicula y luego redirigirá al usuario de vuelta al Top que
	// estaba viendo
	@GetMapping("/eliminarPelicula/{idpelicula}")
	public String deletePelicula(Model model, @PathVariable int idpelicula) {

		Integer idtop = servicedos.encuentraTop(idpelicula).getIdtops();
		servicedos.deletePelicula(idpelicula);

		return "redirect:/base/vertop/" + idtop;
	}

}
