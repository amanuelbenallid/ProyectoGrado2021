package com.MasQuePeliis.models.service;

import java.util.List;

import com.MasQuePeliis.models.entity.Usuario;
import com.MasQuePeliis.models.entity.Usuario_seguidor;

//Definimos los métodos necesarios que usaremos en la aplicación
public interface IUsuario_seguidorService {
	List<Usuario> leerUsuariosSeguidores(Integer id);

	List<Usuario> leerUsuariosNoSeguidores(Integer id);

	Usuario_seguidor registrarSeguimiento(Integer idseguidor, Integer idseguido);

	void dejarDeSeguir(Integer idusuario, Integer idusuarioseguidor);

}
