package com.MasQuePeliis.models.entity;

//Importamos las clases Java necesarias para una entidad
import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

//Usamos las definiciones SpringBoot necesarias para definir que es una entidad y el nombre que tendra la tabla en la Base de datos
@Entity
@Table(name = "peliculas")
public class Pelicula implements Serializable {

	// Establecemos que idpelicula sera la ID y primary key de la tabla
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	// Declaramos las variables
	private Integer idpeliculas;
	private String titulo, descripcionpersonal, enlace;
	private Integer anyo;
	// Establecemos que Pelicula tendra una variable de tipo Top la
	// cual estará relacionada a su correpondiente tabla
	@ManyToOne
	private Top top;

	// Generamos los Constructores , Getters and Setters
	public Integer getIdpeliculas() {
		return idpeliculas;
	}

	public void setIdpeliculas(Integer idpeliculas) {
		this.idpeliculas = idpeliculas;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDescripcionpersonal() {
		return descripcionpersonal;
	}

	public void setDescripcionpersonal(String descripcionpersonal) {
		this.descripcionpersonal = descripcionpersonal;
	}

	public String getEnlace() {
		return enlace;
	}

	public void setEnlace(String enlace) {
		this.enlace = enlace;
	}

	public Integer getAnyo() {
		return anyo;
	}

	public void setAnyo(Integer anyo) {
		this.anyo = anyo;
	}

	public Top getTop() {
		return top;
	}

	public void setTop(Top top) {
		this.top = top;
	}

	public Pelicula(Integer idpeliculas, String titulo, String descripcionpersonal, String enlace, Integer anyo,
			Top top) {
		super();
		this.idpeliculas = idpeliculas;
		this.titulo = titulo;
		this.descripcionpersonal = descripcionpersonal;
		this.enlace = enlace;
		this.anyo = anyo;
		this.top = top;
	}

	public Pelicula() {

	}

}
