package com.MasQuePeliis.models.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MasQuePeliis.models.dao.IComentarioDAO;

import com.MasQuePeliis.models.entity.Comentario;
import com.MasQuePeliis.models.entity.Top;
import com.MasQuePeliis.models.service.IComentarioService;

//Establecemos los comentarios SpringBoot para indicar que es un servicio
@Service
//Implementamos la interfaz del servicio
public class ComentarioServiceImpl implements IComentarioService {

	// Declaramos las variables usando Autowired para inyectar las dependencias de
	// las clases correspondientes
	@Autowired
	private IComentarioDAO data;

	// Usamos Override para hacer referencia a otro metodo e implementarlo
	// En este caso el metodo devuelve una lista de Comentarios y le pasamos el ID
	// del top del cual se quieren obtener los comentarios
	@Override
	public List<Comentario> leerComentariosbyId(Integer idtop) {

		List<Comentario> listacomentarios = new ArrayList<Comentario>();
		// hacemos un bucle en el que repasamos todos los comentarios y obtenemos el ID
		// del top al que pertenecen y si coincide con el ID del top que le
		// proporcionamos lo debera de incluir en la lista de comentarios
		for (int i = 0; i <= data.findAll().size() - 1; i++) {
			if (data.findAll().get(i).getTop().getIdtops() == idtop) {
				listacomentarios.add(data.findAll().get(i));
			}

		}

		return listacomentarios;
	}

	// Este método lo usamos para guardar el comentario que el usuario le pasa
	@Override
	public Comentario registrarComentario(Comentario c) {
		// Llamamos a un método ya creado con el cual guarda los datos introducidos en
		// el repositorio
		return data.save(c);
	}

	// Creamos un método con el cual le pasamos el ID del comentario que deseamos
	// borrar
	@Override
	public void deleteComentario(int idcomentario) {
		data.deleteById(idcomentario);

	}

	@Override
	// Creamos un método para que a traves del ID del comentario se encuentre el Top
	// al que pertenece
	public Top encuentraTop(int idcomentario) {

		return data.getById(idcomentario).getTop();
	}

}
