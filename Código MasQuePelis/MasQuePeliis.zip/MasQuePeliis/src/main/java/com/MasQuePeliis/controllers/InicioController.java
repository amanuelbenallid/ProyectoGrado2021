package com.MasQuePeliis.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

//Desde este controller se consigue que si no se introduce nada en la URL de la aplicación 
//se nos dirija directamente al login de la plataforma
@Controller
public class InicioController {
	@GetMapping("/")
	public String inicio() {
		return "login";
	}

}
