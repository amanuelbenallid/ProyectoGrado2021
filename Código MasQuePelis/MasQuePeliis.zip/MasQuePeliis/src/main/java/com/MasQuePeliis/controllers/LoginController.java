package com.MasQuePeliis.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.MasQuePeliis.models.entity.Usuario;
import com.MasQuePeliis.models.service.IUsuarioService;

//Desde este controller se maneja el mapeo del login y el registro de la plataforma
@Controller
public class LoginController {
	@Autowired
	private IUsuarioService usuarioService;

	// Desde este Get el usuario sera dirigido al login y se le aportara un usuario
	// vacio para que lo rellene e introduzca las credenciales , finalmente estas
	// credenciales seran verificadas con login-post y SpringSecurity
	@GetMapping("/auth/login")
	public String login(Model model) {

		model.addAttribute("usuario", new Usuario());
		return "login";

	}

	// Desde este Mapeo el usuario sera dirigido al formulario de registro de la
	// aplicación y le aportamos usando Model un usuario vacio para que rellene los
	// datos de registro
	@GetMapping("/auth/registro")
	public String registroform(Model model) {
		model.addAttribute("usuario", new Usuario());

		return "registro";
	}

	// Desde este Post se realiza el registro del usuario en el caso de que todo
	// este correcto , si existiera algun error se le redirigiria al mapeo de
	// registro y si fuese todo bien se le redirigirá al login de la plataforma
	@PostMapping("/auth/registro")
	public String registro(@Validated @ModelAttribute Usuario usuario, BindingResult result, Model model) {

		if (result.hasErrors()) {
			return "redirect:/auth/registro";
		} else {
			model.addAttribute("usuario", usuarioService.registrar(usuario));
		}

		return "redirect:/auth/login";
	}

}
