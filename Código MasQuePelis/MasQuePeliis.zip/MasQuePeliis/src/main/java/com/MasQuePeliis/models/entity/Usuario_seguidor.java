package com.MasQuePeliis.models.entity;

//Importamos las clases Java necesarias para una entidad
import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

//Usamos las definiciones SpringBoot necesarias para definir que es una entidad y el nombre que tendra la tabla en la Base de datos
@Entity
@Table(name = "user_follower")
public class Usuario_seguidor implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Establecemos que idseguimiento sera la ID y primary key de la tabla
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idseguimiento;

	public Integer getIdseguimiento() {
		return idseguimiento;
	}

	public void setIdseguimiento(Integer idseguimiento) {
		this.idseguimiento = idseguimiento;
	}

	// Declaramos las variables
	private Integer user_idfollower;
	// Establecemos que Usuario_seguidor tendra una variable de tipo Usuario la
	// cual estará relacionada a su correpondiente tabla
	@ManyToOne
	private Usuario usuario;

	// Generamos los Constructores , Getters and Setters
	public Integer getUser_idfollower() {
		return user_idfollower;
	}

	public void setUser_idfollower(Integer user_idfollower) {
		this.user_idfollower = user_idfollower;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Usuario_seguidor(Integer user_idfollower, Usuario usuario) {
		super();
		this.user_idfollower = user_idfollower;
		this.usuario = usuario;
	}

	public Usuario_seguidor() {

	}

}
