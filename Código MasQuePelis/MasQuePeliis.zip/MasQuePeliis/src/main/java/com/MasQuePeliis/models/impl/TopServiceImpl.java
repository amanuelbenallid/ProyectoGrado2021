package com.MasQuePeliis.models.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MasQuePeliis.models.dao.ITopDAO;
import com.MasQuePeliis.models.dao.IUsuarioDAO;

import com.MasQuePeliis.models.entity.Top;

import com.MasQuePeliis.models.service.ITopService;

@Service
public class TopServiceImpl implements ITopService {
	// Declaramos las variables usando Autowired para inyectar las dependencias de
	// las clases correspondientes
	@Autowired
	private ITopDAO data;
	@Autowired
	private IUsuarioDAO dato;

	// Usamos Override para hacer referencia a otro metodo e implementarlo
	@Override
	// Este método nos devuelve una lista de todos los tops existentes en la Base de
	// datos
	public List<Top> leerTops() {

		return (List<Top>) data.findAll();
	}

	// Este método le pasamos el ID de un top y nos devuelve el Top en si
	@Override
	public Top findTopByid(int id) {

		return data.getById(id);
	}

	// El método siguiente le pasamos el ID de un top y luego nos lo borra de la
	// Base de Datos
	@Override
	public void deleteTop(Integer idtop) {

		data.deleteById(idtop);

	}

	// Este método le pasamos el ID del usario y nos devuelve su username
	public String consultarNombre(Integer userid) {

		return dato.findByIduser(userid).getUsername();
	}

	@Override
	// Este método recibe el ID del usuario y obtiene todos los tops que le
	// pertenezcan o que hayan sido creados por el
	public List<Top> leerTopsMiperfil(Integer idusuario) {

		List<Top> listatops = new ArrayList<Top>();

		for (int i = 0; i <= data.findAll().size() - 1; i++) {
			if (data.findAll().get(i).getUsuario().getIduser() == idusuario) {
				listatops.add(data.findAll().get(i));
			}

		}

		return listatops;
	}

	// El siguiente método lo usamos para guardar el top creado por el usuario en la
	// Base de datos de la aplicación
	@Override
	public int save(Top t) {
		int res = 0;
		Top top = data.save(t);
		if (!top.equals(null)) {
			res = 1;
		}

		return res;
	}

	// Este método recibe una categoria en formato String para luego darle valor al
	// genero la cual es una variable de tipo int y obtiene una lista con todos los
	// tops de esa categoría
	@Override
	public List<Top> leerTopsCategoria(String categoria) {
		List<Top> listatops = new ArrayList<Top>();
		Integer genero = null;
		switch (categoria) {
		case "Accion":
			genero = 1;
			break;
		case "Aventuras":
			genero = 2;
			break;
		case "Romanticas":
			genero = 3;
			break;
		case "Comedia":
			genero = 4;
			break;
		case "Drama":
			genero = 5;
			break;
		case "Terror":
			genero = 6;
			break;
		case "CienciaFiccion":
			genero = 7;
			break;
		case "Musical":
			genero = 8;
			break;
		case "Suspense":
			genero = 9;
			break;

		}

		for (int i = 0; i <= data.findAll().size() - 1; i++) {
			if (data.findAll().get(i).getGeneroid() == genero) {
				listatops.add(data.findAll().get(i));
			}

		}

		return listatops;
	}

	// Este método recibe un top y lo introduce en la Base de datos de la plataforma
	@Override
	public Top registrarTop(Top t) {
		return data.save(t);
	}

	// Ahora definimos los métodos los cuales se encargan de la recopilacion de
	// datos para las estadisticas y por lo tanto son métodos contadores
	@Override
	public Integer contadorAccion() {

		Integer contador = 0;

		for (int i = 0; i <= data.findAll().size() - 1; i++) {
			if (data.findAll().get(i).getGeneroid() == 1) {
				contador++;
			}

		}

		return contador;
	}

	@Override
	public Integer contadorAventuras() {

		Integer contador = 0;

		for (int i = 0; i <= data.findAll().size() - 1; i++) {
			if (data.findAll().get(i).getGeneroid() == 2) {
				contador++;
			}

		}

		return contador;
	}

	@Override
	public Integer contadorRomanticas() {

		Integer contador = 0;

		for (int i = 0; i <= data.findAll().size() - 1; i++) {
			if (data.findAll().get(i).getGeneroid() == 3) {
				contador++;
			}

		}

		return contador;
	}

	@Override
	public Integer contadorComedia() {

		Integer contador = 0;

		for (int i = 0; i <= data.findAll().size() - 1; i++) {
			if (data.findAll().get(i).getGeneroid() == 4) {
				contador++;
			}

		}

		return contador;
	}

	@Override
	public Integer contadorDrama() {

		Integer contador = 0;

		for (int i = 0; i <= data.findAll().size() - 1; i++) {
			if (data.findAll().get(i).getGeneroid() == 5) {
				contador++;
			}

		}

		return contador;
	}

	@Override
	public Integer contadorTerror() {

		Integer contador = 0;

		for (int i = 0; i <= data.findAll().size() - 1; i++) {
			if (data.findAll().get(i).getGeneroid() == 6) {
				contador++;
			}

		}

		return contador;
	}

	@Override
	public Integer contadorCFiccion() {

		Integer contador = 0;

		for (int i = 0; i <= data.findAll().size() - 1; i++) {
			if (data.findAll().get(i).getGeneroid() == 7) {
				contador++;
			}

		}

		return contador;
	}

	@Override
	public Integer contadorMusical() {

		Integer contador = 0;

		for (int i = 0; i <= data.findAll().size() - 1; i++) {
			if (data.findAll().get(i).getGeneroid() == 8) {
				contador++;
			}

		}

		return contador;
	}

	@Override
	public Integer contadorSuspense() {

		Integer contador = 0;

		for (int i = 0; i <= data.findAll().size() - 1; i++) {
			if (data.findAll().get(i).getGeneroid() == 9) {
				contador++;
			}

		}

		return contador;
	}

}
