package com.MasQuePeliis.models.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.MasQuePeliis.models.entity.Usuario;
import com.MasQuePeliis.models.entity.Usuario_seguidor;
//Creamos la conexion con el repositorio de Usuario_seguidor usando JPARepository y además indicamos que la primary key de Usuario_seguidor
//es de tipo Integer
@Repository
public interface IUsuario_seguidorDAO extends JpaRepository<Usuario_seguidor,Integer>{
	
}
