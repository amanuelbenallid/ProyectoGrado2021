package com.MasQuePeliis.models.service;

import java.util.List;

import com.MasQuePeliis.models.entity.Comentario;
import com.MasQuePeliis.models.entity.Top;


//Definimos los métodos necesarios que usaremos en la aplicación
public interface IComentarioService {
	List<Comentario> leerComentariosbyId(Integer idtop);

	Comentario registrarComentario(Comentario c);
	void deleteComentario(int idcomentario);
	Top encuentraTop(int idcomentario);

}
