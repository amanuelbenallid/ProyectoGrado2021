package com.MasQuePeliis.models.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.MasQuePeliis.models.entity.Estreno;

//Creamos la conexion con el repositorio de Estrenos usando JPARepository y además indicamos que la primary key de Estreno
//es de tipo Integer
@Repository
public interface IEstrenoDAO extends JpaRepository<Estreno,Integer>{

}
