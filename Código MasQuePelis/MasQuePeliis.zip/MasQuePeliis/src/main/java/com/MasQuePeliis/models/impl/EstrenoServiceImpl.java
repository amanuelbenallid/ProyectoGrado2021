package com.MasQuePeliis.models.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MasQuePeliis.models.dao.IEstrenoDAO;

import com.MasQuePeliis.models.entity.Estreno;

import com.MasQuePeliis.models.service.IEstrenoService;

@Service
public class EstrenoServiceImpl implements IEstrenoService {

	// Declaramos las variables usando Autowired para inyectar las dependencias de
	// las clases correspondientes
	@Autowired
	private IEstrenoDAO data;

	// Usamos Override para hacer referencia a otro metodo e implementarlo
	@Override
	// En este metodo devolvemos una lista con todos los estrenos que hay en la
	// plataforma
	public List<Estreno> leerEstrenos() {

		return (List<Estreno>) data.findAll();
	}

	// Este método le pasamos el ID de un Estreno y se encarga de llamar a un método
	// predefinido que se encarga de borrar el estreno con dicha ID
	@Override
	public void deleteEstreno(Integer estrenoid) {
		data.deleteById(estrenoid);

	}

	// Este método lo usamos para guardar un estreno en la Base de datos de la
	// plataforma , le pasamos el Estreno creado y el método save() se encarga de
	// guardarlo
	@Override
	public Estreno registrarEstrenos(Estreno e) {

		return data.save(e);
	}

}
