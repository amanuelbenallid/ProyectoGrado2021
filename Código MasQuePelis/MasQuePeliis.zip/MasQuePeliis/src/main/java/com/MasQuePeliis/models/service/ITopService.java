package com.MasQuePeliis.models.service;

import java.util.List;

import com.MasQuePeliis.models.entity.Top;

//Definimos los métodos necesarios que usaremos en la aplicación
public interface ITopService {
	List<Top> leerTops();

	Top findTopByid(int id);

	void deleteTop(Integer idtop);

	List<Top> leerTopsMiperfil(Integer idusuario);

	int save(Top t);

	List<Top> leerTopsCategoria(String categoria);

	Top registrarTop(Top t);

	Integer contadorAccion();

	Integer contadorAventuras();

	Integer contadorRomanticas();

	Integer contadorComedia();

	Integer contadorDrama();

	Integer contadorTerror();

	Integer contadorCFiccion();

	Integer contadorMusical();

	Integer contadorSuspense();

}
