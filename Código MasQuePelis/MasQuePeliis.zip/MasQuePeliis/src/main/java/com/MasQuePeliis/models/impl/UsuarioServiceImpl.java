package com.MasQuePeliis.models.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.MasQuePeliis.models.dao.IUsuarioDAO;

import com.MasQuePeliis.models.entity.Usuario;
import com.MasQuePeliis.models.service.IUsuarioService;

@Service
public class UsuarioServiceImpl implements IUsuarioService {
	// Declaramos las variables usando Autowired para inyectar las dependencias de
	// las clases correspondientes
	@Autowired
	BCryptPasswordEncoder passwordEncoder;

	@Autowired
	private IUsuarioDAO usuarioDao;

	// Usamos Override para hacer referencia a otro metodo e implementarlo
	@Override
	public Usuario findbyUsername(String username) {
		return usuarioDao.findByUsername(username);
	}

	@Override
	// Este método se usa para guardar un usuario en la Base de datos despues de que
	// el usuario rellene el formulario en la vista de registro
	public Usuario registrar(Usuario u) {

		u.setPassword(passwordEncoder.encode(u.getPassword()));
		u.setRole("user");
		u.setState("activo");

		return usuarioDao.save(u);

	}

	// Este método recibe el ID del usuario deseado y devuelve el usuario en si
	@Override
	public Usuario findbyIdUser(Integer iduser) {

		return usuarioDao.findByIduser(iduser);
	}

	// Este método se usa para guardar el usuario en la Base de Datos
	@Override
	public int save(Usuario u) {
		int res = 0;
		Usuario usuario = usuarioDao.save(u);
		if (!usuario.equals(null)) {
			res = 1;
		}

		return res;
	}

	@Override
	// Este método devuelve una lista de todos los usuarios activos de la plataforma
	public List<Usuario> leerUsuariosActivos() {

		List<Usuario> listausuarios = new ArrayList<Usuario>();

		for (int i = 0; i <= usuarioDao.findAll().size() - 1; i++) {
			if (usuarioDao.findAll().get(i).getState().equals("activo")) {
				listausuarios.add(usuarioDao.findAll().get(i));
			}

		}

		return (List<Usuario>) listausuarios;
	}

	@Override
	// Este método devuelve una lista de todos los usuarios suspendidos de la
	// plataforma
	public List<Usuario> leerUsuariosInactivos() {

		List<Usuario> listausuarios = new ArrayList<Usuario>();

		for (int i = 0; i <= usuarioDao.findAll().size() - 1; i++) {
			if (usuarioDao.findAll().get(i).getState().equals("inactivo")) {
				listausuarios.add(usuarioDao.findAll().get(i));
			}

		}

		return (List<Usuario>) listausuarios;
	}

	@Override
	// Este método recibe el ID del usuario que se desea eliminar y se llama al
	// método deletebyId que lo elimina de la Base de datos
	public void deleteUser(Integer iduser) {

		usuarioDao.deleteById(iduser);
	}

}
