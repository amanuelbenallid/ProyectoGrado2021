-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema masquepelis
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema masquepelis
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `masquepelis` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `masquepelis` ;

-- -----------------------------------------------------
-- Table `masquepelis`.`user`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `masquepelis`.`user` (
  `iduser` INT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(45) NULL DEFAULT NULL,
  `password` VARCHAR(255) NULL DEFAULT NULL,
  `email` VARCHAR(45) NULL DEFAULT NULL,
  `nombre` VARCHAR(45) NULL DEFAULT NULL,
  `apellido` VARCHAR(45) NULL DEFAULT NULL,
  `role` VARCHAR(45) NULL DEFAULT NULL,
  `state` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`iduser`))
ENGINE = InnoDB
AUTO_INCREMENT = 31
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `masquepelis`.`tops`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `masquepelis`.`tops` (
  `idtops` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NULL DEFAULT NULL,
  `generoid` INT NULL DEFAULT NULL,
  `usuario_iduser` INT NULL DEFAULT NULL,
  `userid` INT NULL DEFAULT NULL,
  PRIMARY KEY (`idtops`),
  INDEX `FKi2qu1tmnf9hq09ps6xyn3j30r` (`usuario_iduser` ASC) VISIBLE,
  CONSTRAINT `FKi2qu1tmnf9hq09ps6xyn3j30r`
    FOREIGN KEY (`usuario_iduser`)
    REFERENCES `masquepelis`.`user` (`iduser`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 69
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `masquepelis`.`comentarios`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `masquepelis`.`comentarios` (
  `idcomentarios` INT NOT NULL AUTO_INCREMENT,
  `fecha` VARCHAR(100) NULL DEFAULT NULL,
  `top_idtops` INT NULL DEFAULT NULL,
  `usuario_iduser` INT NULL DEFAULT NULL,
  `contenidocomentario` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`idcomentarios`),
  INDEX `FKc56jdlbyj07pwommb3arcry27` (`top_idtops` ASC) VISIBLE,
  INDEX `FKqpnfexfqk25upolxwqtgd454v` (`usuario_iduser` ASC) VISIBLE,
  CONSTRAINT `FKc56jdlbyj07pwommb3arcry27`
    FOREIGN KEY (`top_idtops`)
    REFERENCES `masquepelis`.`tops` (`idtops`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `FKqpnfexfqk25upolxwqtgd454v`
    FOREIGN KEY (`usuario_iduser`)
    REFERENCES `masquepelis`.`user` (`iduser`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 810
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `masquepelis`.`estrenos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `masquepelis`.`estrenos` (
  `idestrenos` INT NOT NULL AUTO_INCREMENT,
  `titulo` VARCHAR(45) NULL DEFAULT NULL,
  `sinopsis` VARCHAR(2000) NULL DEFAULT NULL,
  `anyo` INT NULL DEFAULT NULL,
  `director` VARCHAR(45) NULL DEFAULT NULL,
  `duracion` INT NULL DEFAULT NULL,
  `protagonista` VARCHAR(45) NULL DEFAULT NULL,
  `generoid` INT NULL DEFAULT NULL,
  `ilustracion` LONGTEXT NULL DEFAULT NULL,
  PRIMARY KEY (`idestrenos`))
ENGINE = InnoDB
AUTO_INCREMENT = 78
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `masquepelis`.`genero`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `masquepelis`.`genero` (
  `idgenero` INT NOT NULL,
  `genero` VARCHAR(45) NULL DEFAULT NULL,
  `descripcion` VARCHAR(100) NULL DEFAULT NULL,
  PRIMARY KEY (`idgenero`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `masquepelis`.`peliculas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `masquepelis`.`peliculas` (
  `idpeliculas` INT NOT NULL AUTO_INCREMENT,
  `titulo` VARCHAR(450) NULL DEFAULT NULL,
  `anyo` INT NULL DEFAULT NULL,
  `descripcionpersonal` VARCHAR(3000) NULL DEFAULT NULL,
  `enlace` VARCHAR(1000) NULL DEFAULT NULL,
  `top_idtops` INT NULL DEFAULT NULL,
  PRIMARY KEY (`idpeliculas`),
  INDEX `FKnbcnn8fpw3omkxosxihx2jhns_idx` (`top_idtops` ASC) VISIBLE,
  CONSTRAINT `FKnbcnn8fpw3omkxosxihx2jhns`
    FOREIGN KEY (`top_idtops`)
    REFERENCES `masquepelis`.`tops` (`idtops`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 307
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `masquepelis`.`role`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `masquepelis`.`role` (
  `idrole` INT NOT NULL,
  `role` VARCHAR(45) NULL DEFAULT NULL,
  `descripcion` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`idrole`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `masquepelis`.`state`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `masquepelis`.`state` (
  `idstate` INT NOT NULL,
  `state` VARCHAR(45) NULL DEFAULT NULL,
  `descripcion` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`idstate`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `masquepelis`.`user_follower`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `masquepelis`.`user_follower` (
  `idseguimiento` INT NOT NULL AUTO_INCREMENT,
  `user_idfollower` INT NULL DEFAULT NULL,
  `usuario_iduser` INT NULL DEFAULT NULL,
  PRIMARY KEY (`idseguimiento`),
  INDEX `FKf8y326j7udoewp15r5qdd6o1g` (`usuario_iduser` ASC) VISIBLE,
  CONSTRAINT `FKf8y326j7udoewp15r5qdd6o1g`
    FOREIGN KEY (`usuario_iduser`)
    REFERENCES `masquepelis`.`user` (`iduser`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 156
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
