CREATE DATABASE  IF NOT EXISTS `masquepelis` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `masquepelis`;
-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: masquepelis
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_follower`
--

DROP TABLE IF EXISTS `user_follower`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_follower` (
  `idseguimiento` int NOT NULL AUTO_INCREMENT,
  `user_idfollower` int DEFAULT NULL,
  `usuario_iduser` int DEFAULT NULL,
  PRIMARY KEY (`idseguimiento`),
  KEY `FKf8y326j7udoewp15r5qdd6o1g` (`usuario_iduser`),
  CONSTRAINT `FKf8y326j7udoewp15r5qdd6o1g` FOREIGN KEY (`usuario_iduser`) REFERENCES `user` (`iduser`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_follower`
--

LOCK TABLES `user_follower` WRITE;
/*!40000 ALTER TABLE `user_follower` DISABLE KEYS */;
INSERT INTO `user_follower` VALUES (44,1,2),(50,2,11),(51,2,16),(52,2,10),(53,3,4),(54,3,6),(55,3,8),(56,3,13),(57,3,15),(58,3,12),(59,4,2),(60,4,7),(61,4,11),(62,4,12),(63,4,14),(64,4,16),(65,5,3),(66,5,8),(67,5,9),(68,5,11),(69,5,4),(70,5,14),(71,6,3),(72,6,7),(73,6,10),(74,6,9),(75,6,8),(76,6,5),(77,7,3),(78,7,11),(79,7,5),(80,7,10),(81,7,8),(82,7,17),(83,8,2),(84,8,2),(85,8,3),(86,8,4),(87,8,5),(88,8,6),(89,9,7),(90,9,8),(91,9,9),(92,9,10),(93,9,11),(94,9,12),(95,10,13),(96,10,14),(97,10,15),(98,10,16),(99,10,17),(100,10,17),(101,11,16),(102,11,15),(103,11,14),(104,11,13),(105,11,12),(106,11,10),(107,12,9),(108,12,8),(109,12,7),(110,12,6),(111,12,5),(112,12,4),(113,13,3),(114,13,2),(115,13,2),(116,13,2),(117,13,2),(118,13,3),(119,14,4),(120,14,5),(121,14,6),(122,14,7),(123,14,8),(124,14,9),(125,15,10),(126,15,11),(127,15,12),(128,15,13),(129,15,14),(130,15,16),(131,16,17),(132,16,17),(133,16,15),(134,16,14),(135,16,13),(136,16,12),(137,17,11),(138,17,10),(139,17,9),(140,17,8),(141,17,7),(142,17,6),(143,13,5),(153,2,12),(154,2,3),(155,2,8);
/*!40000 ALTER TABLE `user_follower` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-18 17:33:18
