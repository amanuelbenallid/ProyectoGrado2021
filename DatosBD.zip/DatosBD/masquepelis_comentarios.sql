CREATE DATABASE  IF NOT EXISTS `masquepelis` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `masquepelis`;
-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: masquepelis
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comentarios`
--

DROP TABLE IF EXISTS `comentarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comentarios` (
  `idcomentarios` int NOT NULL AUTO_INCREMENT,
  `fecha` varchar(100) DEFAULT NULL,
  `top_idtops` int DEFAULT NULL,
  `usuario_iduser` int DEFAULT NULL,
  `contenidocomentario` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idcomentarios`),
  KEY `FKc56jdlbyj07pwommb3arcry27` (`top_idtops`),
  KEY `FKqpnfexfqk25upolxwqtgd454v` (`usuario_iduser`),
  CONSTRAINT `FKc56jdlbyj07pwommb3arcry27` FOREIGN KEY (`top_idtops`) REFERENCES `tops` (`idtops`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FKqpnfexfqk25upolxwqtgd454v` FOREIGN KEY (`usuario_iduser`) REFERENCES `user` (`iduser`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=810 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comentarios`
--

LOCK TABLES `comentarios` WRITE;
/*!40000 ALTER TABLE `comentarios` DISABLE KEYS */;
INSERT INTO `comentarios` VALUES (1,'2021-12-15 14:39:02.128',1,6,'Muy buen Top'),(2,'2021-12-15 14:42:07.134',1,7,'Estupendo!!'),(3,'2021-12-15 14:51:04.116',1,8,'Estoy de acuerdo con la elección de Películas'),(4,'2021-12-15 14:39:02.128',2,6,'Muy buen Top'),(5,'2021-12-15 14:42:07.134',2,7,'Estupendo!!'),(6,'2021-12-15 14:51:04.116',2,8,'Estoy de acuerdo con la elección de Películas'),(7,'2021-12-15 14:39:02.128',3,6,'Muy buen Top'),(8,'2021-12-15 14:42:07.134',3,7,'Estupendo!!'),(9,'2021-12-15 14:51:04.116',3,8,'Estoy de acuerdo con la elección de Películas'),(10,'2021-12-15 14:39:02.128',4,6,'Muy buen Top'),(11,'2021-12-15 14:42:07.134',4,7,'Estupendo!!'),(12,'2021-12-15 14:51:04.116',4,8,'Estoy de acuerdo con la elección de Películas'),(13,'2021-12-15 14:39:02.128',5,6,'Muy buen Top'),(14,'2021-12-15 14:42:07.134',5,7,'Estupendo!!'),(15,'2021-12-15 14:51:04.116',5,8,'Estoy de acuerdo con la elección de Películas'),(16,'2021-12-15 14:39:02.128',6,6,'Muy buen Top'),(17,'2021-12-15 14:42:07.134',6,7,'Estupendo!!'),(18,'2021-12-15 14:51:04.116',6,8,'Estoy de acuerdo con la elección de Películas'),(19,'2021-12-15 14:39:02.128',7,6,'Muy buen Top'),(20,'2021-12-15 14:42:07.134',7,7,'Estupendo!!'),(21,'2021-12-15 14:51:04.116',7,8,'Estoy de acuerdo con la elección de Películas'),(22,'2021-12-15 14:39:02.128',8,6,'Muy buen Top'),(23,'2021-12-15 14:42:07.134',8,7,'Estupendo!!'),(24,'2021-12-15 14:51:04.116',8,8,'Estoy de acuerdo con la elección de Películas'),(25,'2021-12-15 14:39:02.128',9,6,'Muy buen Top'),(26,'2021-12-15 14:42:07.134',9,7,'Estupendo!!'),(27,'2021-12-15 14:51:04.116',9,8,'Estoy de acuerdo con la elección de Películas'),(28,'2021-12-15 14:39:02.128',10,6,'Muy buen Top'),(29,'2021-12-15 14:42:07.134',10,7,'Estupendo!!'),(30,'2021-12-15 14:51:04.116',10,8,'Estoy de acuerdo con la elección de Películas'),(31,'2021-12-15 14:39:02.128',11,6,'Muy buen Top'),(32,'2021-12-15 14:42:07.134',11,7,'Estupendo!!'),(33,'2021-12-15 14:51:04.116',11,8,'Estoy de acuerdo con la elección de Películas'),(34,'2021-12-15 14:39:02.128',12,6,'Muy buen Top'),(35,'2021-12-15 14:42:07.134',12,7,'Estupendo!!'),(36,'2021-12-15 14:51:04.116',12,8,'Estoy de acuerdo con la elección de Películas'),(37,'2021-12-15 14:39:02.128',13,6,'Muy buen Top'),(38,'2021-12-15 14:42:07.134',13,7,'Estupendo!!'),(39,'2021-12-15 14:51:04.116',13,8,'Estoy de acuerdo con la elección de Películas'),(40,'2021-12-15 14:39:02.128',14,6,'Muy buen Top'),(41,'2021-12-15 14:42:07.134',14,7,'Estupendo!!'),(42,'2021-12-15 14:51:04.116',14,8,'Estoy de acuerdo con la elección de Películas'),(43,'2021-12-15 14:39:02.128',15,6,'Muy buen Top'),(44,'2021-12-15 14:42:07.134',15,7,'Estupendo!!'),(45,'2021-12-15 14:51:04.116',15,8,'Estoy de acuerdo con la elección de Películas'),(46,'2021-12-15 14:39:02.128',16,6,'Muy buen Top'),(47,'2021-12-15 14:42:07.134',16,7,'Estupendo!!'),(48,'2021-12-15 14:51:04.116',16,8,'Estoy de acuerdo con la elección de Películas'),(49,'2021-12-15 14:39:02.128',17,6,'Muy buen Top'),(50,'2021-12-15 14:42:07.134',17,7,'Estupendo!!'),(51,'2021-12-15 14:51:04.116',17,8,'Estoy de acuerdo con la elección de Películas'),(52,'2021-12-15 14:39:02.128',18,6,'Muy buen Top'),(53,'2021-12-15 14:42:07.134',18,7,'Estupendo!!'),(54,'2021-12-15 14:51:04.116',18,8,'Estoy de acuerdo con la elección de Películas'),(55,'2021-12-15 14:39:02.128',19,6,'Muy buen Top'),(56,'2021-12-15 14:42:07.134',19,7,'Estupendo!!'),(57,'2021-12-15 14:51:04.116',19,8,'Estoy de acuerdo con la elección de Películas'),(58,'2021-12-15 14:39:02.128',20,6,'Muy buen Top'),(59,'2021-12-15 14:42:07.134',20,7,'Estupendo!!'),(60,'2021-12-15 14:51:04.116',20,8,'Estoy de acuerdo con la elección de Películas'),(61,'2021-12-15 14:39:02.128',21,6,'Muy buen Top'),(62,'2021-12-15 14:42:07.134',21,7,'Estupendo!!'),(63,'2021-12-15 14:51:04.116',21,8,'Estoy de acuerdo con la elección de Películas'),(64,'2021-12-15 14:39:02.128',22,6,'Muy buen Top'),(65,'2021-12-15 14:42:07.134',22,7,'Estupendo!!'),(66,'2021-12-15 14:51:04.116',22,8,'Estoy de acuerdo con la elección de Películas'),(67,'2021-12-15 14:39:02.128',23,6,'Muy buen Top'),(68,'2021-12-15 14:42:07.134',23,7,'Estupendo!!'),(69,'2021-12-15 14:51:04.116',23,8,'Estoy de acuerdo con la elección de Películas'),(70,'2021-12-15 14:39:02.128',24,6,'Muy buen Top'),(71,'2021-12-15 14:42:07.134',24,7,'Estupendo!!'),(72,'2021-12-15 14:51:04.116',24,8,'Estoy de acuerdo con la elección de Películas'),(73,'2021-12-15 14:39:02.128',25,6,'Muy buen Top'),(74,'2021-12-15 14:42:07.134',25,7,'Estupendo!!'),(75,'2021-12-15 14:51:04.116',25,8,'Estoy de acuerdo con la elección de Películas'),(76,'2021-12-15 14:39:02.128',26,6,'Muy buen Top'),(77,'2021-12-15 14:42:07.134',26,7,'Estupendo!!'),(78,'2021-12-15 14:51:04.116',26,8,'Estoy de acuerdo con la elección de Películas'),(79,'2021-12-15 14:39:02.128',27,6,'Muy buen Top'),(80,'2021-12-15 14:42:07.134',27,7,'Estupendo!!'),(81,'2021-12-15 14:51:04.116',27,8,'Estoy de acuerdo con la elección de Películas'),(82,'2021-12-15 14:39:02.128',28,6,'Muy buen Top'),(83,'2021-12-15 14:42:07.134',28,7,'Estupendo!!'),(84,'2021-12-15 14:51:04.116',28,8,'Estoy de acuerdo con la elección de Películas'),(85,'2021-12-15 14:39:02.128',29,6,'Muy buen Top'),(86,'2021-12-15 14:42:07.134',29,7,'Estupendo!!'),(87,'2021-12-15 14:51:04.116',29,8,'Estoy de acuerdo con la elección de Películas'),(88,'2021-12-15 14:39:02.128',30,6,'Muy buen Top'),(89,'2021-12-15 14:42:07.134',30,7,'Estupendo!!'),(90,'2021-12-15 14:51:04.116',30,8,'Estoy de acuerdo con la elección de Películas'),(91,'2021-12-15 14:39:02.128',31,6,'Muy buen Top'),(92,'2021-12-15 14:42:07.134',31,7,'Estupendo!!'),(93,'2021-12-15 14:51:04.116',31,8,'Estoy de acuerdo con la elección de Películas'),(94,'2021-12-15 14:39:02.128',32,6,'Muy buen Top'),(95,'2021-12-15 14:42:07.134',32,7,'Estupendo!!'),(96,'2021-12-15 14:51:04.116',32,8,'Estoy de acuerdo con la elección de Películas'),(97,'2021-12-15 14:39:02.128',33,6,'Muy buen Top'),(98,'2021-12-15 14:42:07.134',33,7,'Estupendo!!'),(99,'2021-12-15 14:51:04.116',33,8,'Estoy de acuerdo con la elección de Películas'),(100,'2021-12-15 14:39:02.128',34,6,'Muy buen Top'),(101,'2021-12-15 14:42:07.134',34,7,'Estupendo!!'),(102,'2021-12-15 14:51:04.116',34,8,'Estoy de acuerdo con la elección de Películas'),(103,'2021-12-15 14:39:02.128',35,6,'Muy buen Top'),(104,'2021-12-15 14:42:07.134',35,7,'Estupendo!!'),(105,'2021-12-15 14:51:04.116',35,8,'Estoy de acuerdo con la elección de Películas'),(106,'2021-12-15 14:39:02.128',36,6,'Muy buen Top'),(107,'2021-12-15 14:42:07.134',36,7,'Estupendo!!'),(108,'2021-12-15 14:51:04.116',36,8,'Estoy de acuerdo con la elección de Películas'),(112,'2021-12-15 14:39:02.128',38,6,'Muy buen Top'),(113,'2021-12-15 14:42:07.134',38,7,'Estupendo!!'),(114,'2021-12-15 14:51:04.116',38,8,'Estoy de acuerdo con la elección de Películas'),(115,'2021-12-15 14:39:02.128',39,6,'Muy buen Top'),(116,'2021-12-15 14:42:07.134',39,7,'Estupendo!!'),(117,'2021-12-15 14:51:04.116',39,8,'Estoy de acuerdo con la elección de Películas'),(118,'2021-12-15 14:39:02.128',40,6,'Muy buen Top'),(119,'2021-12-15 14:42:07.134',40,7,'Estupendo!!'),(120,'2021-12-15 14:51:04.116',40,8,'Estoy de acuerdo con la elección de Películas');
/*!40000 ALTER TABLE `comentarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-18 17:33:18
